(function(){
  $('#msbo').on('click', function(){
    $('body').toggleClass('msb-x');
  });
}());